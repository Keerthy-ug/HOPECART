import 'dart:io';

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:food_donation/bindings/controller_bindings.dart';
import 'package:food_donation/constants.dart';
import 'package:food_donation/controllers/Authentication/authentication_repository.dart';
import 'package:food_donation/controllers/signup_controller.dart';
import 'package:food_donation/firebase_options.dart';
import 'package:food_donation/screens/user.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SharedPreferences pref = await SharedPreferences.getInstance();
  final userType = pref.getString('userType');
  Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform).then(
      (value) =>
          Get.put(AuthenticationRepository(userType: userType, prefs: pref)));
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      initialBinding: ControllerBindings(),
      debugShowCheckedModeBanner: false,
      title: 'Hand 2 Hand',
      theme: ThemeData(
        fontFamily: "Cairo",
        scaffoldBackgroundColor: kBackgroundColor,
        textTheme: Theme.of(context).textTheme.apply(displayColor: kTextColor),
      ),
      home: const Center(child: const CircularProgressIndicator()),
    );
  }
}
