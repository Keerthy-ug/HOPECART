import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:food_donation/controllers/Authentication/authentication_repository.dart';
import 'package:food_donation/controllers/donation_controller.dart';
import 'package:food_donation/models/donation_model.dart';
import 'package:food_donation/screens/Doner/status_doner.dart';
import 'package:get/get.dart';

class cloth extends StatefulWidget {
  const cloth({super.key});

  @override
  State<cloth> createState() => _clothState();
}

class _clothState extends State<cloth> {
  @override
  _clothState() {
    _selectedval = _cloth[0];
  }
  final _cloth = ['Shirts', 'T-shirts', 'Pants', 'Trousers'];
  final controller = Get.find<DonationController>();
  final auth = Get.find<AuthenticationRepository>();
  final _formKey = GlobalKey<FormState>();

  String? _selectedval;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: <Widget>[
          Form(
            key: _formKey,
            child: Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height * .6,
              decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage('assets/images/cloth.jpg'),
                      fit: BoxFit.cover)),
            ),
          ),
          AppBar(
            elevation: 0,
            backgroundColor: Colors.transparent,
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              padding: const EdgeInsets.all(50.0),
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height * .5,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(60.0),
                      topRight: Radius.circular(60.0))),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    "Cloths",
                    style:
                        TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 30.0),
                  DropdownButtonFormField(
                    items: _cloth.map((e) {
                      return DropdownMenuItem(
                        child: Text(e),
                        value: e,
                      );
                    }).toList(),
                    onChanged: (val) {
                      setState(() {
                        _selectedval = val as String;
                      });
                    },
                    icon: const Icon(Icons.arrow_drop_down_circle,
                        color: Color.fromARGB(255, 244, 143, 177)),
                    dropdownColor: Colors.pink.shade50,
                    decoration: InputDecoration(
                        labelText: "Cloth Type",
                        border: UnderlineInputBorder()),
                  ),
                  SizedBox(height: 20.0),
                  TextFormField(
                    controller: controller.quantity,
                    cursorColor: Color.fromARGB(255, 244, 143, 177),
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                        hintText: "Quantity",
                        prefixIcon: Icon(Icons.verified_outlined)),
                  ),
                  SizedBox(height: 30.0),
                  SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5.0)),
                          backgroundColor: Colors.pink.shade200,
                          foregroundColor: Colors.white,
                        ),
                        child: Text("Donate"),
                        onPressed: () {
                          final donations = donation_model(
                              email: auth.firebaseUser.value?.email,
                              type: 'Cloth',
                              item: _selectedval,
                              quantity: int.parse(controller.quantity.text),
                              timestamp: Timestamp.now());
                          DonationController.instance.insertDonation(donations);
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => status_doner()),
                          );
                        },
                      )),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
