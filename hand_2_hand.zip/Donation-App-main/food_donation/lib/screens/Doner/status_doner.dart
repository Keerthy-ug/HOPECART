import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:food_donation/controllers/donation_controller.dart';
import 'package:food_donation/models/donation_model.dart';
import 'package:food_donation/widgets/bottom_nav_bar.dart';
import 'package:food_donation/widgets/status.dart';
import 'package:get/get.dart';

class status_doner extends StatefulWidget {
  const status_doner({super.key});

  @override
  State<status_doner> createState() => _status_donerState();
}

class _status_donerState extends State<status_doner> {
  final controller = Get.find<DonationController>();
  @override
  Widget build(BuildContext context) {
    timeToString(Timestamp? t) {
      DateTime d = t!.toDate();
      return d.toString();
    }

    var size = MediaQuery.of(context).size;
    return Scaffold(
      bottomNavigationBar: BottomNavBar(
        home: false,
        status: true,
        profile: false,
      ),
      body: FutureBuilder<List<donation_model>>(
        future: controller.getDonationData(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            if (snapshot.hasData) {
              return ListView.builder(
                  itemCount: snapshot.data!.length,
                  itemBuilder: (context, index) {
                    return status(
                        date: timeToString(snapshot.data![index].timestamp),
                        isApprove: snapshot.data![index].approve,
                        type: snapshot.data![index].type.toString());
                  });
            } else if (snapshot.hasError) {
              return Center(
                child: Text(snapshot.error.toString()),
              );
            } else {
              return Text('Something went wrong.');
            }
          } else {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
        },
      ),
    );
  }
}
