import 'package:flutter/material.dart';
import 'package:food_donation/screens/Doner/doner_signup.dart';
import 'package:food_donation/screens/Orphanage/orpahange_login.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/category_card.dart';

class user_ extends StatelessWidget {
  final SharedPreferences prefs;
  user_(this.prefs);

  setUser(String userType) async {
    prefs.setString('userType', userType);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(children: [
          Center(
            child: Column(
              children: [
                SizedBox(
                  height: MediaQuery.sizeOf(context).height * .15,
                ),
                Container(
                  height: 250,
                  width: 200,
                  child: CategoryCard(
                      svgSrc: 'assets/icons/orphanage.png',
                      title: 'Orphanage',
                      press: () {
                        setUser('Orphanage');
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => orphanage_login()),
                        );
                        print(prefs.getString('userType'));
                      }),
                ),
                SizedBox(
                  height: 20,
                ),
                Container(
                  height: 250,
                  width: 200,
                  child: CategoryCard(
                      svgSrc: 'assets/icons/donate.png',
                      title: 'Doner',
                      press: () {
                        setUser('Doner');
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => doner_signup()),
                        );
                      }),
                )
              ],
            ),
          ),
        ]),
      ),
    );
  }
}
