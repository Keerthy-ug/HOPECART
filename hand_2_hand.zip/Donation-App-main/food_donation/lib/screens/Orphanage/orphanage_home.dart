import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:food_donation/screens/Orphanage/cloth_request.dart';
import 'package:food_donation/screens/Orphanage/medicine_request.dart';
import 'package:food_donation/screens/Orphanage/stationery_request.dart';
import 'package:food_donation/widgets/bottom_nav_bar.dart';
import 'package:food_donation/widgets/category_card.dart';
import 'package:google_fonts/google_fonts.dart';

import 'food_request.dart';

class orphanage_home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context)
        .size; //this gonna give us total height and with of our device
    return Scaffold(
      bottomNavigationBar: BottomNavBar(
        home: true,
        status: false,
        profile: false,
      ),
      body: Stack(
        children: <Widget>[
          Container(
            // Here the height of the container is 45% of our total height
            height: size.height * .45,
            decoration: BoxDecoration(
              color: Color(0xFFF5CEB8),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  // Align(
                  //   alignment: Alignment.topRight,
                  //   child: Container(
                  //     alignment: Alignment.center,
                  //     height: 52,
                  //     width: 52,
                  //     decoration: BoxDecoration(
                  //       color: Color(0xFFF2BEA1),
                  //       shape: BoxShape.circle,
                  //     ),
                  //     child: SvgPicture.asset("assets/icons/menu.svg"),
                  //   ),
                  // ),
                  SizedBox(height: 20.0),
                  Text(
                    "Hello",
                    style: GoogleFonts.kalam(
                        fontSize: 40,
                        fontWeight: FontWeight.w600,
                        color: Colors.black54),
                  ),
                  SizedBox(height: 80.0),
                  Expanded(
                    child: GridView.count(
                      crossAxisCount: 2,
                      childAspectRatio: .85,
                      crossAxisSpacing: 20,
                      mainAxisSpacing: 20,
                      children: <Widget>[
                        CategoryCard(
                          title: "Food",
                          svgSrc: "assets/icons/diet.png",
                          press: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => food_request()),
                            );
                          },
                        ),
                        CategoryCard(
                          title: "Stationery items",
                          svgSrc: "assets/icons/stationery.png",
                          press: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => stationery_request()),
                            );
                          },
                        ),
                        CategoryCard(
                          title: "cloth",
                          svgSrc: "assets/icons/clothes.png",
                          press: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => cloth_request()),
                            );
                          },
                        ),
                        CategoryCard(
                          title: "Medicines",
                          svgSrc: "assets/icons/medicine.png",
                          press: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => medicine_request()),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
