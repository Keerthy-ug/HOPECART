import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:food_donation/controllers/Authentication/authentication_repository.dart';
import 'package:food_donation/controllers/request_controller.dart';
import 'package:food_donation/screens/Orphanage/status_orphanage.dart';
import 'package:get/get.dart';

import '../../models/request_model.dart';

class stationery_request extends StatefulWidget {
  const stationery_request({super.key});

  @override
  State<stationery_request> createState() => _stationery_requestState();
}

class _stationery_requestState extends State<stationery_request> {
  @override
  _stationery_requestState() {
    _selectedval = _cloth[0];
  }

  final _cloth = ['Pencil', 'Pen', 'Notebook', 'Text Books'];
  final controller = Get.find<RequestController>();
  final auth = Get.find<AuthenticationRepository>();
  final _formKey = GlobalKey<FormState>();

  String? _selectedval;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: <Widget>[
          Form(
            key: _formKey,
            child: Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height * .6,
              decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage('assets/images/stationery.jfif'),
                      fit: BoxFit.cover)),
            ),
          ),
          AppBar(
            elevation: 0,
            backgroundColor: Colors.transparent,
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              padding: const EdgeInsets.all(50.0),
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height * .5,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(60.0),
                      topRight: Radius.circular(60.0))),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    "Staionery",
                    style:
                        TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 30.0),
                  DropdownButtonFormField(
                    items: _cloth.map((e) {
                      return DropdownMenuItem(
                        child: Text(e),
                        value: e,
                      );
                    }).toList(),
                    onChanged: (val) {
                      setState(() {
                        _selectedval = val as String;
                      });
                    },
                    icon: const Icon(Icons.arrow_drop_down_circle,
                        color: Color.fromARGB(255, 244, 143, 177)),
                    dropdownColor: Colors.pink.shade50,
                    decoration: InputDecoration(
                        labelText: "Stationery items",
                        border: UnderlineInputBorder()),
                  ),
                  SizedBox(height: 20.0),
                  TextFormField(
                    controller: controller.quantity,
                    cursorColor: Color.fromARGB(255, 244, 143, 177),
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                        hintText: "Quantity",
                        prefixIcon: Icon(Icons.verified_outlined)),
                  ),
                  SizedBox(height: 30.0),
                  SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5.0)),
                          backgroundColor: Colors.pink.shade200,
                          foregroundColor: Colors.white,
                        ),
                        child: Text("Request"),
                        onPressed: () {
                          final donations = request_model(
                              email: auth.firebaseUser.value?.email,
                              type: 'Food',
                              item: _selectedval,
                              quantity: int.parse(controller.quantity.text),
                              timestamp: Timestamp.now());
                          RequestController.instance.insertRequests(donations);
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => status_orphanage()),
                          );
                        },
                      )),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
