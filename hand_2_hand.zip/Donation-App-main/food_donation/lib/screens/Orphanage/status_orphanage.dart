import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:food_donation/controllers/request_controller.dart';
import 'package:food_donation/models/request_model.dart';
import 'package:food_donation/widgets/bottom_nav_bar.dart';
import 'package:food_donation/widgets/status.dart';
import 'package:get/get.dart';

class status_orphanage extends StatefulWidget {
  const status_orphanage({super.key});

  @override
  State<status_orphanage> createState() => _status_orphanageState();
}

class _status_orphanageState extends State<status_orphanage> {
  final controller = Get.find<RequestController>();
  @override
  Widget build(BuildContext context) {
    timeToString(Timestamp? t) {
      DateTime d = t!.toDate();
      return d.toString();
    }

    var size = MediaQuery.of(context).size;
    return Scaffold(
      bottomNavigationBar: BottomNavBar(
        home: false,
        status: true,
        profile: false,
      ),
      body: FutureBuilder<List<request_model>>(
        future: controller.getRequestData(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            if (snapshot.hasData) {
              return ListView.builder(
                  itemCount: snapshot.data!.length,
                  itemBuilder: (context, index) {
                    return status(
                        date: timeToString(snapshot.data![index].timestamp),
                        isApprove: snapshot.data![index].approve,
                        type: snapshot.data![index].type.toString());
                  });
            } else if (snapshot.hasError) {
              return Center(
                child: Text(snapshot.error.toString()),
              );
            } else {
              return Text('Something went wrong.');
            }
          } else {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
        },
      ),
    );
  }
}
