import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../models/request_model.dart';
import 'Authentication/authentication_repository.dart';

class RequestController extends GetxController {
  static RequestController get instance => Get.find();

  //TextField Controllers to get data from TextFields
  final item = TextEditingController();
  final quantity = TextEditingController();
  final donationRepo = Get.put(RequestRepository());
  final authRepo = Get.put(AuthenticationRepository(userType: 'Orphanage'));
  //Call this Function from Design & it will do the rest

  void insertRequests(request_model donations) {
    donationRepo.createRequests(donations);
  }

  getRequestData() {
    final email = authRepo.firebaseUser.value?.email;
    if (email != null) {
      return donationRepo.getRequestDetails(email);
    } else {
      Get.snackbar('Error', 'Login to continue');
    }
  }
}
