import 'package:firebase_auth/firebase_auth.dart';
import 'package:food_donation/controllers/login_controller.dart';
import 'package:food_donation/controllers/signup_controller.dart';
import 'package:food_donation/screens/Doner/doner_home.dart';
import 'package:food_donation/screens/Doner/doner_signup.dart';
import 'package:food_donation/screens/Orphanage/orpahange_login.dart';
import 'package:food_donation/screens/Orphanage/orphanage_home.dart';
import 'package:food_donation/screens/user.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthenticationRepository extends GetxController {
  static AuthenticationRepository get instance => Get.find();
  final userType;
  final prefs;
  AuthenticationRepository({this.userType, this.prefs});
  //Variables
  final _auth = FirebaseAuth.instance;
  late final Rx<User?> firebaseUser;

  //Will be load when app launches this func will be called and set the firebaseUser state
  @override
  void onReady() {
    firebaseUser = Rx<User?>(_auth.currentUser);
    firebaseUser.bindStream(_auth.userChanges());
    ever(firebaseUser, _setInitialScreen);
  }

  /// If we are setting initial screen from here
  /// then in the main.dart => App() add CircularProgressIndicator()
  _setInitialScreen(User? user) {
    if (userType == 'Doner') {
      user == null
          ? Get.offAll(() => const doner_signup())
          : Get.offAll(() => doner_home());
    }
    if (userType == 'Orphanage') {
      user == null
          ? Get.offAll(() => const orphanage_login())
          : Get.offAll(() => orphanage_home());
    }
    if (userType == null) {
      Get.offAll(() => user_(prefs));
    }
  }

  //FUNC
  Future<String?> createUserWithEmailAndPassword(
      String email, String password) async {
    try {
      await _auth.createUserWithEmailAndPassword(
          email: email, password: password);
      firebaseUser.value != null
          ? Get.offAll(() => doner_home())
          : Get.to(() => const doner_signup());
    } on FirebaseAuthException catch (e) {
      final ex = SignUpWithEmailAndPasswordFailure.code(e.code);
      print('FIREBASE AUTH EXCEPTION - ${ex.message}');
      throw ex;
    } catch (_) {
      const ex = SignUpWithEmailAndPasswordFailure();
      print('EXCEPTION - {ex.message}');
      throw ex;
    }
    return null;
  }

  Future<String?> loginWithEmailAndPassword(
      String email, String password) async {
    try {
      await _auth.signInWithEmailAndPassword(email: email, password: password);
    } on FirebaseAuthException catch (_) {
      // final ex = LogInWithEmailAndPasswordFailure.(e.code);
      // return ex.message;
    } catch (_) {
      const ex = LogInWithEmailAndPasswordFailure();
      return ex.message;
    }
    return null;
  }

  Future<void> logout() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.remove('userType');
    await _auth.signOut();
  }
}
