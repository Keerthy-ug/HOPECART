import 'package:flutter/widgets.dart';
import 'package:food_donation/controllers/Authentication/authentication_repository.dart';
import 'package:food_donation/models/donation_model.dart';
import 'package:get/get.dart';

class DonationController extends GetxController {
  static DonationController get instance => Get.find();

  //TextField Controllers to get data from TextFields
  final item = TextEditingController();
  final quantity = TextEditingController();
  final donationRepo = Get.put(donationRepository());
  final authRepo = Get.put(AuthenticationRepository(userType: 'Doner'));
  //Call this Function from Design & it will do the rest

  void insertDonation(donation_model donations) {
    donationRepo.createDonations(donations);
  }

  getDonationData() {
    final email = authRepo.firebaseUser.value?.email;
    if (email != null) {
      return donationRepo.getDonationDetails(email);
    } else {
      Get.snackbar('Error', 'Login to continue');
    }
  }
}
