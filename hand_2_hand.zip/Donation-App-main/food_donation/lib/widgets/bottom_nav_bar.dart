import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:food_donation/constants.dart';
import 'package:food_donation/controllers/Authentication/authentication_repository.dart';
import 'package:food_donation/screens/Doner/doner_home.dart';
import 'package:food_donation/screens/Doner/status_doner.dart';
import 'package:get/get.dart';

class BottomNavBar extends StatelessWidget {
  final bool status;
  final bool home;
  final bool profile;
  const BottomNavBar({
    Key? key,
    required this.home,
    required this.status,
    required this.profile,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 40, vertical: 10),
      height: 80,
      color: Colors.white,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          BottomNavItem(
            title: "History",
            svgScr: Icons.history,
            isActive: status,
            press: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => status_doner()),
              );
            },
          ),
          BottomNavItem(
            title: "Home",
            svgScr: Icons.home,
            isActive: home,
            press: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => doner_home()),
              );
            },
          ),
          BottomNavItem(
            title: "Logout",
            svgScr: Icons.logout_outlined,
            isActive: profile,
            press: () {
              AuthenticationRepository.instance.logout();
            },
          ),
        ],
      ),
    );
  }
}

class BottomNavItem extends StatelessWidget {
  final IconData svgScr;
  final String title;
  final VoidCallback press;
  final bool isActive;
  const BottomNavItem({
    Key? key,
    required this.svgScr,
    required this.title,
    required this.press,
    this.isActive = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: press,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: <Widget>[
          Icon(
            svgScr,
            color: isActive ? kActiveIconColor : kTextColor,
          ),
          // SvgPicture.asset(
          //   svgScr,
          //   color: isActive ? kActiveIconColor : kTextColor,
          // ),
          Text(
            title,
            style: TextStyle(color: isActive ? kActiveIconColor : kTextColor),
          ),
        ],
      ),
    );
  }
}
