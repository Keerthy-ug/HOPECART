import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class status extends StatelessWidget {
  final String date;
  final bool? isApprove;
  final String type;
  const status(
      {super.key,
      required this.date,
      required this.isApprove,
      required this.type});
  returnImage(String type) {
    if (type == 'Food') {
      return Image.asset("assets/icons/diet.png");
    }
    if (type == 'Cloth') {
      return Image.asset("assets/icons/clothes.png");
    }
    if (type == 'Stationery') {
      return Image.asset("assets/icons/stationery.png");
    }
    if (type == 'Medicine') {
      return Image.asset("assets/icons/medicine.png");
    }
  }

  approveCheck(bool? isApprove) {
    return isApprove == true
        ? const Icon(Icons.check)
        : const Icon(Icons.pending);
  }

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: returnImage(type),
      title: Text(type),
      subtitle: Text(date),
      trailing: approveCheck(isApprove),
    );
  }
}
