import 'package:food_donation/controllers/donation_controller.dart';
import 'package:food_donation/controllers/login_controller.dart';
import 'package:food_donation/controllers/signup_controller.dart';
import 'package:get/get.dart';

import '../controllers/request_controller.dart';

class ControllerBindings implements Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => LoginController(), fenix: true);
    Get.lazyPut(() => SignUpController(), fenix: true);
    Get.lazyPut(() => DonationController(), fenix: true);
    Get.lazyPut(() => RequestController(), fenix: true);
    
  }
}
